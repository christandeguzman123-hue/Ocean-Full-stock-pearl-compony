(function () {
  const FEATURED_IDS = [1, 6, 10, 16];
  const mount = document.getElementById('featured');
  if (!mount) return;
  OT.products()
    .then((products) => {
      const picks = FEATURED_IDS.map((id) => products.find((p) => p.id === id)).filter(Boolean);
      mount.replaceChildren(...picks.map((p) => OT.productCard(p, { onView: OT.productModal })));
    })
    .catch((err) => {
      mount.replaceChildren(OT.h('p', { class: 'muted', text: err.message }));
    });
})();
