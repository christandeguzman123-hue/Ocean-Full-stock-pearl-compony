(function () {
  const grid = document.getElementById('products');
  const chips = document.getElementById('chips');
  const search = document.getElementById('search');
  const sort = document.getElementById('sort');
  const count = document.getElementById('count');
  const empty = document.getElementById('empty');
  const loadError = document.getElementById('load-error');

  const state = { products: [], category: 'All', query: '', sort: 'default' };

  const params = new URLSearchParams(location.search);
  if (params.get('category')) state.category = params.get('category');

  function visible() {
    const q = state.query.trim().toLowerCase();
    let list = state.products.filter((p) => {
      if (state.category !== 'All' && p.category !== state.category) return false;
      if (!q) return true;
      return [p.name, p.category, p.description, p.benefit].some((t) => t.toLowerCase().includes(q));
    });
    if (state.sort === 'price-asc') list = list.slice().sort((a, b) => a.price - b.price || a.id - b.id);
    else if (state.sort === 'price-desc') list = list.slice().sort((a, b) => b.price - a.price || a.id - b.id);
    else if (state.sort === 'name') list = list.slice().sort((a, b) => a.name.localeCompare(b.name));
    return list;
  }

  function renderChips() {
    const categories = ['All', ...new Set(state.products.map((p) => p.category))];
    if (!categories.includes(state.category)) state.category = 'All';
    chips.replaceChildren(
      ...categories.map((c) =>
        OT.h('button', {
          class: 'chip',
          type: 'button',
          text: c,
          'aria-pressed': String(c === state.category),
          onclick() {
            state.category = c;
            renderChips();
            renderGrid();
          },
        })
      )
    );
  }

  function renderGrid() {
    const list = visible();
    grid.replaceChildren(...list.map((p) => OT.productCard(p, { onView: OT.productModal })));
    empty.hidden = list.length > 0;
    count.textContent = `Showing ${list.length} of ${state.products.length} products`;
  }

  search.addEventListener('input', () => {
    state.query = search.value;
    renderGrid();
  });
  sort.addEventListener('change', () => {
    state.sort = sort.value;
    renderGrid();
  });

  OT.products()
    .then((products) => {
      state.products = products;
      renderChips();
      renderGrid();
    })
    .catch((err) => {
      loadError.textContent = err.message;
      loadError.hidden = false;
    });
})();
