(function () {
  const CONFIRM_KEY = 'ot_last_order';
  const empty = document.getElementById('empty');
  const layout = document.getElementById('checkout-layout');
  const confirmation = document.getElementById('confirmation');
  const form = document.getElementById('order-form');
  const errorBox = document.getElementById('error');
  const submit = document.getElementById('submit');
  const loadError = document.getElementById('load-error');
  let products = [];

  function summaryRow(name, quantity, amount) {
    return OT.h('li', null, [OT.h('span', { text: `${name} × ${quantity}` }), OT.h('span', { text: OT.peso(amount) })]);
  }

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = false;
    errorBox.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }

  function showConfirmation(order) {
    empty.hidden = true;
    layout.hidden = true;
    confirmation.hidden = false;
    document.getElementById('reference').textContent = order.reference;
    document.getElementById('confirm-items').replaceChildren(
      ...order.items.map((i) => summaryRow(i.name, i.quantity, i.unitPrice * i.quantity))
    );
    document.getElementById('confirm-total').textContent = OT.peso(order.subtotal);
    document.getElementById('confirm-status').textContent = 'Received – awaiting confirmation';
    document.getElementById('confirm-date').textContent = OT.formatDate(order.createdAt);
    window.scrollTo({ top: 0 });
  }

  function render() {
    const lines = OT.cart.lines(products);
    if (lines.length === 0) {
      empty.hidden = false;
      layout.hidden = true;
      return;
    }
    empty.hidden = true;
    layout.hidden = false;
    document.getElementById('summary-items').replaceChildren(
      ...lines.map((l) => summaryRow(l.product.name, l.quantity, l.total))
    );
    const sum = lines.reduce((s, l) => s + l.total, 0);
    document.getElementById('subtotal').textContent = OT.peso(sum);
    document.getElementById('total').textContent = OT.peso(sum);
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    errorBox.hidden = true;
    const data = {
      name: form.name.value,
      email: form.email.value,
      phone: form.phone.value,
      address: form.address.value,
      notes: form.notes.value,
      consent: form.consent.checked,
      marketing: form.marketing.checked,
      items: OT.cart.items().map((i) => ({ id: i.id, quantity: i.quantity })),
    };
    if (!data.consent) {
      showError('Please tick the consent box to agree to the Data Privacy Notice before placing your order.');
      return;
    }
    OT.setBusy(submit, true, 'Sending…');
    try {
      const order = await OT.api('/api/orders', { method: 'POST', body: data });
      try {
        sessionStorage.setItem(CONFIRM_KEY, JSON.stringify(order));
      } catch {
        void 0;
      }
      OT.cart.clear();
      form.reset();
      showConfirmation(order);
    } catch (err) {
      showError(err.message);
    } finally {
      OT.setBusy(submit, false, 'Place Order Inquiry');
    }
  });

  OT.products()
    .then((list) => {
      products = list;
      let saved = null;
      try {
        saved = JSON.parse(sessionStorage.getItem(CONFIRM_KEY) || 'null');
      } catch {
        saved = null;
      }
      if (OT.cart.count() === 0 && saved && saved.reference) showConfirmation(saved);
      else render();
    })
    .catch((err) => {
      loadError.textContent = err.message;
      loadError.hidden = false;
    });
})();
