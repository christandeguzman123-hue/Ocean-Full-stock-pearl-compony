(function () {
  const root = document.getElementById('admin-root');
  const h = OT.h;
  let status = null;
  let tab = 'orders';
  let orderFilter = 'All';
  let inquiryFilter = 'All';

  function field(id, label, type, extra) {
    return h('div', { class: 'field' }, [
      h('label', { for: id, text: label }),
      h('input', { id, name: id, type, required: true, autocomplete: 'off', maxlength: '128', ...extra }),
    ]);
  }

  function errorBox() {
    return h('div', { class: 'form-error', role: 'alert', hidden: true });
  }

  function show(box, message) {
    box.textContent = message;
    box.hidden = false;
  }

  function authCard(title, intro, fields, buttonLabel, onSubmit) {
    const box = errorBox();
    const button = h('button', { class: 'btn btn-primary btn-block', type: 'submit', text: buttonLabel });
    const form = h('form', { novalidate: true }, [box, ...fields, button]);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      box.hidden = true;
      OT.setBusy(button, true);
      try {
        await onSubmit(form, box);
      } catch (err) {
        show(box, err.message);
      } finally {
        OT.setBusy(button, false);
      }
    });
    return h('div', { class: 'card auth-card' }, [h('h2', { text: title }), h('p', { class: 'muted', text: intro }), form]);
  }

  function renderSetup() {
    root.replaceChildren(
      authCard(
        'Create administrator account',
        'No administrator exists yet. Create the account that will review inquiries and orders. Use a strong password of at least 10 characters with letters and numbers.',
        [
          field('username', 'Username', 'text', { minlength: '3', maxlength: '40', autocomplete: 'username' }),
          field('password', 'Password', 'password', { autocomplete: 'new-password' }),
          field('confirm', 'Confirm password', 'password', { autocomplete: 'new-password' }),
        ],
        'Create account',
        async (form) => {
          if (form.password.value !== form.confirm.value) throw new Error('Passwords do not match.');
          await OT.api('/api/admin/setup', { method: 'POST', body: { username: form.username.value, password: form.password.value } });
          await boot();
        }
      )
    );
  }

  function renderLogin() {
    root.replaceChildren(
      authCard(
        'Staff sign in',
        'Authorized Ocean Treasures personnel only.',
        [
          field('username', 'Username', 'text', { autocomplete: 'username' }),
          field('password', 'Password', 'password', { autocomplete: 'current-password' }),
        ],
        'Sign in',
        async (form) => {
          await OT.api('/api/admin/login', { method: 'POST', body: { username: form.username.value, password: form.password.value } });
          await boot();
        }
      )
    );
  }

  function pill(value) {
    return h('span', { class: 'status-pill s-' + value, text: value });
  }

  function statusSelect(options, current, onChange) {
    const select = h('select', { 'aria-label': 'Status' }, options.map((o) => h('option', { value: o, text: o, selected: o === current })));
    select.addEventListener('change', () => onChange(select.value));
    return select;
  }

  function dl(rows) {
    return h(
      'dl',
      null,
      rows.filter(([, v]) => v !== '' && v !== null && v !== undefined).flatMap(([k, v]) => [h('dt', { text: k }), h('dd', { text: v })])
    );
  }

  function filterBar(options, current, onChange, label) {
    const select = h('select', { 'aria-label': label }, ['All', ...options].map((o) => h('option', { value: o, text: o === 'All' ? 'All statuses' : o, selected: o === current })));
    select.addEventListener('change', () => onChange(select.value));
    return h('div', { class: 'sort' }, [select]);
  }

  async function changeStatus(kind, id, value) {
    try {
      await OT.api(`/api/admin/${kind}/${id}`, { method: 'PATCH', body: { status: value } });
      OT.toast('Status updated');
      await renderTab();
    } catch (err) {
      OT.toast(err.message);
      await renderTab();
    }
  }

  async function remove(kind, id, label) {
    if (!window.confirm(`Permanently delete ${label}? This cannot be undone.`)) return;
    try {
      await OT.api(`/api/admin/${kind}/${id}`, { method: 'DELETE' });
      OT.toast('Record deleted');
      await renderTab();
    } catch (err) {
      OT.toast(err.message);
    }
  }

  function orderCard(o) {
    const table = h('table', { class: 'items-table' }, [
      h('thead', null, [h('tr', null, [h('th', { text: 'Item' }), h('th', { class: 'num', text: 'Price' }), h('th', { class: 'num', text: 'Qty' }), h('th', { class: 'num', text: 'Total' })])]),
      h('tbody', null, [
        ...o.items.map((i) =>
          h('tr', null, [h('td', { text: i.name }), h('td', { class: 'num', text: OT.peso(i.unitPrice) }), h('td', { class: 'num', text: String(i.quantity) }), h('td', { class: 'num', text: OT.peso(i.unitPrice * i.quantity) })])
        ),
        h('tr', null, [h('td', { text: 'Subtotal' }), h('td'), h('td'), h('td', { class: 'num', text: OT.peso(o.subtotal) })]),
      ]),
    ]);
    return h('article', { class: 'record' }, [
      h('div', { class: 'record-head' }, [
        h('div', null, [h('h3', { text: o.reference }), h('div', { class: 'record-meta', text: 'Received ' + OT.formatDate(o.createdAt) })]),
        pill(o.status),
      ]),
      dl([
        ['Customer', o.customerName],
        ['Email', o.email],
        ['Contact number', o.phone],
        ['Delivery address', o.address],
        ['Notes', o.notes],
        ['Promotions', o.marketingOptIn ? 'Opted in' : 'Not opted in'],
        ['Consent recorded', OT.formatDate(o.consentAt)],
      ]),
      table,
      h('div', { class: 'record-actions' }, [
        h('label', { class: 'inline-label', text: 'Order status' }),
        statusSelect(status.orderStatuses, o.status, (v) => changeStatus('orders', o.id, v)),
        h('button', { class: 'btn btn-danger btn-sm', type: 'button', text: 'Delete', onclick: () => remove('orders', o.id, 'order ' + o.reference) }),
      ]),
    ]);
  }

  function inquiryCard(q) {
    return h('article', { class: 'record' }, [
      h('div', { class: 'record-head' }, [
        h('div', null, [h('h3', { text: q.subject || 'Inquiry' }), h('div', { class: 'record-meta', text: 'Received ' + OT.formatDate(q.createdAt) })]),
        pill(q.status),
      ]),
      dl([
        ['Name', q.name],
        ['Email', q.email],
        ['Contact number', q.phone],
        ['Message', q.message],
        ['Promotions', q.marketingOptIn ? 'Opted in' : 'Not opted in'],
        ['Consent recorded', OT.formatDate(q.consentAt)],
      ]),
      h('div', { class: 'record-actions' }, [
        h('label', { class: 'inline-label', text: 'Inquiry status' }),
        statusSelect(status.inquiryStatuses, q.status, (v) => changeStatus('inquiries', q.id, v)),
        h('button', { class: 'btn btn-danger btn-sm', type: 'button', text: 'Delete', onclick: () => remove('inquiries', q.id, 'this inquiry') }),
      ]),
    ]);
  }

  function renderAccount(mount) {
    const authBox = errorBox();
    const ok = h('div', { class: 'notice', role: 'status', hidden: true });
    const button = h('button', { class: 'btn btn-primary', type: 'submit', text: 'Change password' });
    const form = h('form', { class: 'card auth-card', novalidate: true }, [
      h('h3', { text: 'Change password' }),
      authBox,
      ok,
      field('currentPassword', 'Current password', 'password', { autocomplete: 'current-password' }),
      field('newPassword', 'New password', 'password', { autocomplete: 'new-password' }),
      field('confirmPassword', 'Confirm new password', 'password', { autocomplete: 'new-password' }),
      button,
    ]);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      authBox.hidden = true;
      ok.hidden = true;
      if (form.newPassword.value !== form.confirmPassword.value) return show(authBox, 'New passwords do not match.');
      OT.setBusy(button, true);
      try {
        await OT.api('/api/admin/password', { method: 'POST', body: { currentPassword: form.currentPassword.value, newPassword: form.newPassword.value } });
        form.reset();
        ok.textContent = 'Password updated.';
        ok.hidden = false;
      } catch (err) {
        show(authBox, err.message);
      } finally {
        OT.setBusy(button, false);
      }
    });
    mount.replaceChildren(form);
  }

  async function renderTab() {
    const mount = document.getElementById('tab-panel');
    if (!mount) return;
    if (tab === 'account') return renderAccount(mount);
    try {
      if (tab === 'orders') {
        const orders = await OT.api('/api/admin/orders');
        const list = orders.filter((o) => orderFilter === 'All' || o.status === orderFilter);
        mount.replaceChildren(
          h('div', { class: 'admin-top' }, [
            h('strong', { text: `${list.length} of ${orders.length} orders` }),
            filterBar(status.orderStatuses, orderFilter, (v) => { orderFilter = v; renderTab(); }, 'Filter orders by status'),
          ]),
          ...(list.length ? list.map(orderCard) : [h('div', { class: 'empty', text: 'No orders to show.' })])
        );
      } else {
        const inquiries = await OT.api('/api/admin/inquiries');
        const list = inquiries.filter((q) => inquiryFilter === 'All' || q.status === inquiryFilter);
        mount.replaceChildren(
          h('div', { class: 'admin-top' }, [
            h('strong', { text: `${list.length} of ${inquiries.length} inquiries` }),
            filterBar(status.inquiryStatuses, inquiryFilter, (v) => { inquiryFilter = v; renderTab(); }, 'Filter inquiries by status'),
          ]),
          ...(list.length ? list.map(inquiryCard) : [h('div', { class: 'empty', text: 'No inquiries to show.' })])
        );
      }
    } catch (err) {
      if (err.status === 401) return boot();
      mount.replaceChildren(h('div', { class: 'form-error', text: err.message }));
    }
  }

  function renderDashboard() {
    const tabs = [['orders', 'Orders'], ['inquiries', 'Inquiries'], ['account', 'Account']];
    const bar = h('div', { class: 'tabs', role: 'tablist' }, tabs.map(([key, label]) =>
      h('button', {
        type: 'button',
        role: 'tab',
        text: label,
        'aria-selected': String(key === tab),
        onclick() {
          tab = key;
          for (const b of bar.children) b.setAttribute('aria-selected', String(b.textContent === label));
          renderTab();
        },
      })
    ));
    root.replaceChildren(
      h('div', { class: 'admin-top' }, [
        h('div', null, [h('p', { class: 'eyebrow', text: 'Staff area' }), h('h1', { text: 'Orders & Inquiries' }), h('p', { class: 'muted', text: 'Signed in as ' + status.username })]),
        h('button', {
          class: 'btn btn-outline btn-sm',
          type: 'button',
          text: 'Sign out',
          async onclick() {
            await OT.api('/api/admin/logout', { method: 'POST', body: {} }).catch(() => {});
            await boot();
          },
        }),
      ]),
      bar,
      h('div', { id: 'tab-panel' })
    );
    renderTab();
  }

  async function boot() {
    try {
      status = await OT.api('/api/admin/status');
    } catch (err) {
      root.replaceChildren(h('div', { class: 'form-error', text: err.message }));
      return;
    }
    if (status.setupRequired) renderSetup();
    else if (!status.authenticated) renderLogin();
    else renderDashboard();
  }

  boot();
})();
