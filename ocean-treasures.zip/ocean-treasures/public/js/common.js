(function () {
  const OT = {};
  window.OT = OT;

  OT.peso = function (n) {
    return '₱' + Number(n).toLocaleString('en-PH');
  };

  OT.h = function (tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      for (const [key, value] of Object.entries(attrs)) {
        if (value === undefined || value === null || value === false) continue;
        if (key === 'text') node.textContent = value;
        else if (key === 'class') node.className = value;
        else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2), value);
        else if (value === true) node.setAttribute(key, '');
        else node.setAttribute(key, value);
      }
    }
    const list = Array.isArray(children) ? children : children === undefined ? [] : [children];
    for (const child of list) {
      if (child === null || child === undefined || child === false) continue;
      node.append(child.nodeType ? child : document.createTextNode(String(child)));
    }
    return node;
  };

  OT.api = async function (url, options = {}) {
    const init = { method: options.method || 'GET', headers: {}, credentials: 'same-origin' };
    if (options.body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(options.body);
    }
    let res;
    try {
      res = await fetch(url, init);
    } catch {
      throw new Error('Could not reach the local application. Please restart it and try again.');
    }
    let data = null;
    try {
      data = await res.json();
    } catch {
      data = null;
    }
    if (!res.ok) {
      const err = new Error((data && data.error) || 'Something went wrong. Please try again.');
      err.status = res.status;
      throw err;
    }
    return data;
  };

  let productsPromise = null;
  OT.products = function () {
    if (!productsPromise) {
      productsPromise = OT.api('/api/products').catch((err) => {
        productsPromise = null;
        throw err;
      });
    }
    return productsPromise;
  };

  const CART_KEY = 'ot_cart';
  const listeners = [];

  function readCart() {
    try {
      const raw = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
      if (!Array.isArray(raw)) return [];
      return raw
        .map((i) => ({ id: Number(i.id), quantity: Math.min(20, Math.max(1, Math.floor(Number(i.quantity)))) }))
        .filter((i) => Number.isInteger(i.id) && i.id > 0 && Number.isFinite(i.quantity));
    } catch {
      return [];
    }
  }

  function writeCart(items) {
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(items));
    } catch {
      memoryCart = items;
    }
    OT.cart.notify();
  }

  let memoryCart = null;

  OT.cart = {
    items() {
      return memoryCart || readCart();
    },
    count() {
      return this.items().reduce((sum, i) => sum + i.quantity, 0);
    },
    add(id, quantity = 1) {
      const items = this.items();
      const found = items.find((i) => i.id === id);
      if (found) found.quantity = Math.min(20, found.quantity + quantity);
      else items.push({ id, quantity: Math.min(20, quantity) });
      writeCart(items);
    },
    setQuantity(id, quantity) {
      const q = Math.floor(Number(quantity));
      if (!Number.isFinite(q) || q < 1) return;
      writeCart(this.items().map((i) => (i.id === id ? { id, quantity: Math.min(20, q) } : i)));
    },
    remove(id) {
      writeCart(this.items().filter((i) => i.id !== id));
    },
    clear() {
      writeCart([]);
    },
    onChange(fn) {
      listeners.push(fn);
    },
    notify() {
      for (const fn of listeners) fn();
    },
    lines(products) {
      const byId = new Map(products.map((p) => [p.id, p]));
      const lines = [];
      for (const item of this.items()) {
        const product = byId.get(item.id);
        if (product) lines.push({ product, quantity: item.quantity, total: product.price * item.quantity });
      }
      return lines;
    },
  };

  OT.toast = function (message) {
    let node = document.getElementById('toast');
    if (!node) {
      node = OT.h('div', { id: 'toast', class: 'toast', role: 'status', 'aria-live': 'polite' });
      document.body.append(node);
    }
    node.textContent = message;
    node.classList.add('show');
    clearTimeout(OT.toast.timer);
    OT.toast.timer = setTimeout(() => node.classList.remove('show'), 2400);
  };

  OT.formatDate = function (iso) {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '';
    return d.toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' });
  };

  const NAV = [
    ['/', 'Home', 'home'],
    ['/shop', 'Shop', 'shop'],
    ['/about', 'About Us', 'about'],
    ['/contact', 'Contact Us', 'contact'],
  ];

  function renderHeader(page) {
    const mount = document.getElementById('site-header');
    if (!mount) return;
    const badge = OT.h('span', { class: 'badge', id: 'cart-badge', 'aria-label': 'Items in cart', hidden: true });
    const nav = OT.h('nav', { class: 'nav', id: 'main-nav', 'aria-label': 'Main' }, [
      ...NAV.map(([href, label, key]) =>
        OT.h('a', { href, text: label, 'aria-current': key === page ? 'page' : false })
      ),
      OT.h('a', { href: '/cart', class: 'cart-link', 'aria-current': page === 'cart' ? 'page' : false }, ['Cart', badge]),
    ]);
    const toggle = OT.h('button', {
      class: 'nav-toggle',
      type: 'button',
      'aria-expanded': 'false',
      'aria-controls': 'main-nav',
      text: 'Menu',
      onclick() {
        const open = nav.classList.toggle('open');
        toggle.setAttribute('aria-expanded', String(open));
      },
    });
    mount.className = 'site-header';
    mount.replaceChildren(
      OT.h('div', { class: 'container header-inner' }, [
        OT.h('a', { class: 'brand', href: '/', 'aria-label': 'Ocean Treasures home' }, [
          OT.h('img', { src: '/images/logo.png', alt: 'Ocean Treasures Fine Jewelry' }),
        ]),
        toggle,
        nav,
      ])
    );
    const update = () => {
      const n = OT.cart.count();
      badge.textContent = String(n);
      badge.hidden = n === 0;
    };
    update();
    OT.cart.onChange(update);
    window.addEventListener('storage', update);
  }

  function renderFooter() {
    const mount = document.getElementById('site-footer');
    if (!mount) return;
    mount.className = 'site-footer';
    mount.replaceChildren(
      OT.h('div', { class: 'container' }, [
        OT.h('div', { class: 'footer-grid' }, [
          OT.h('div', null, [
            OT.h('div', { class: 'footer-logo' }, [OT.h('img', { src: '/images/logo.png', alt: 'Ocean Treasures' })]),
            OT.h('p', {
              text: 'Elegant, ocean-inspired jewelry featuring pearls, shells, starfish and the beauty of the sea.',
            }),
          ]),
          OT.h('div', null, [
            OT.h('h4', { text: 'Explore' }),
            OT.h('a', { href: '/', text: 'Home' }),
            OT.h('a', { href: '/shop', text: 'Shop the Collection' }),
            OT.h('a', { href: '/about', text: 'About Us' }),
            OT.h('a', { href: '/contact', text: 'Contact Us' }),
          ]),
          OT.h('div', null, [
            OT.h('h4', { text: 'Information' }),
            OT.h('a', { href: '/cart', text: 'Your Cart' }),
            OT.h('a', { href: '/privacy', text: 'Data Privacy Notice' }),
            OT.h('a', { href: '/admin', text: 'Staff Login' }),
          ]),
        ]),
        OT.h('div', { class: 'footer-bottom' }, [
          OT.h('span', { text: '© ' + new Date().getFullYear() + ' Ocean Treasures. All rights reserved.' }),
          OT.h('span', { text: 'Your information is handled in line with the Data Privacy Act of 2012 (RA 10173).' }),
        ]),
      ])
    );
  }

  OT.productCard = function (product, handlers) {
    const open = () => handlers.onView(product);
    return OT.h('article', { class: 'product-card' }, [
      OT.h(
        'button',
        { class: 'product-media', type: 'button', 'aria-label': 'View details for ' + product.name, onclick: open },
        [OT.h('img', { src: product.image, alt: product.name, loading: 'lazy' })]
      ),
      OT.h('div', { class: 'product-body' }, [
        OT.h('span', { class: 'product-cat', text: product.category }),
        OT.h('h3', { class: 'product-name', text: product.name }),
        OT.h('p', { class: 'product-desc', text: product.description }),
        OT.h('div', { class: 'product-foot' }, [
          OT.h('span', { class: 'price', text: OT.peso(product.price) }),
          OT.h('div', { class: 'product-actions' }, [
            OT.h('button', { class: 'btn btn-outline btn-sm', type: 'button', text: 'Details', onclick: open }),
            OT.h('button', {
              class: 'btn btn-primary btn-sm',
              type: 'button',
              text: 'Add to cart',
              onclick() {
                OT.cart.add(product.id, 1);
                OT.toast(product.name + ' added to your cart');
              },
            }),
          ]),
        ]),
      ]),
    ]);
  };

  OT.productModal = function (product) {
    let dialog = document.getElementById('product-dialog');
    if (!dialog) {
      dialog = OT.h('dialog', { id: 'product-dialog', 'aria-labelledby': 'product-dialog-title' });
      dialog.addEventListener('click', (e) => {
        if (e.target === dialog) dialog.close();
      });
      document.body.append(dialog);
    }
    const qtyInput = OT.h('input', {
      type: 'number',
      min: '1',
      max: '20',
      value: '1',
      'aria-label': 'Quantity',
    });
    const clamp = () => {
      const n = Math.floor(Number(qtyInput.value));
      qtyInput.value = String(Number.isFinite(n) ? Math.min(20, Math.max(1, n)) : 1);
      return Number(qtyInput.value);
    };
    dialog.replaceChildren(
      OT.h('div', { class: 'modal' }, [
        OT.h('button', {
          class: 'modal-close',
          type: 'button',
          'aria-label': 'Close',
          text: '×',
          onclick: () => dialog.close(),
        }),
        OT.h('div', { class: 'modal-media' }, [OT.h('img', { src: product.image, alt: product.name })]),
        OT.h('div', { class: 'modal-body' }, [
          OT.h('span', { class: 'product-cat', text: product.category }),
          OT.h('h3', { id: 'product-dialog-title', text: product.name }),
          OT.h('div', { class: 'price', text: OT.peso(product.price) }),
          OT.h('div', { class: 'detail-label', text: 'Design & materials' }),
          OT.h('p', { text: product.description }),
          OT.h('div', { class: 'detail-label', text: 'Why you will love it' }),
          OT.h('p', { text: product.benefit }),
          OT.h('div', { class: 'modal-buy' }, [
            OT.h('div', { class: 'qty' }, [
              OT.h('button', { type: 'button', 'aria-label': 'Decrease quantity', text: '−', onclick: () => { qtyInput.value = String(clamp() - 1); clamp(); } }),
              qtyInput,
              OT.h('button', { type: 'button', 'aria-label': 'Increase quantity', text: '+', onclick: () => { qtyInput.value = String(clamp() + 1); clamp(); } }),
            ]),
            OT.h('button', {
              class: 'btn btn-gold',
              type: 'button',
              text: 'Add to cart',
              onclick() {
                OT.cart.add(product.id, clamp());
                OT.toast(product.name + ' added to your cart');
                dialog.close();
              },
            }),
          ]),
        ]),
      ])
    );
    qtyInput.addEventListener('change', clamp);
    dialog.showModal();
  };

  OT.setBusy = function (button, busy, label) {
    button.disabled = busy;
    if (label !== undefined) button.textContent = label;
  };

  document.addEventListener('DOMContentLoaded', () => {
    const page = document.body.dataset.page;
    renderHeader(page);
    renderFooter();
  });
})();
