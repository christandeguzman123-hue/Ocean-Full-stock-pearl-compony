(function () {
  const empty = document.getElementById('empty');
  const cart = document.getElementById('cart');
  const itemsMount = document.getElementById('items');
  const subtotal = document.getElementById('subtotal');
  const total = document.getElementById('total');
  const loadError = document.getElementById('load-error');
  let products = [];

  function render() {
    const lines = OT.cart.lines(products);
    const known = new Set(products.map((p) => p.id));
    for (const item of OT.cart.items()) if (!known.has(item.id)) OT.cart.remove(item.id);

    if (lines.length === 0) {
      empty.hidden = false;
      cart.hidden = true;
      return;
    }
    empty.hidden = true;
    cart.hidden = false;

    itemsMount.replaceChildren(
      ...lines.map(({ product, quantity, total: lineTotal }) => {
        const input = OT.h('input', { type: 'number', min: '1', max: '20', value: String(quantity), 'aria-label': 'Quantity for ' + product.name });
        const apply = (n) => OT.cart.setQuantity(product.id, n);
        input.addEventListener('change', () => {
          const n = Math.floor(Number(input.value));
          apply(Number.isFinite(n) && n >= 1 ? n : quantity);
          render();
        });
        return OT.h('div', { class: 'cart-item' }, [
          OT.h('img', { src: product.image, alt: product.name }),
          OT.h('div', null, [
            OT.h('h3', { text: product.name }),
            OT.h('div', { class: 'unit', text: OT.peso(product.price) + ' each' }),
            OT.h('div', { class: 'cart-controls' }, [
              OT.h('div', { class: 'qty' }, [
                OT.h('button', { type: 'button', 'aria-label': 'Decrease quantity', text: '−', onclick() { apply(quantity - 1); render(); } }),
                input,
                OT.h('button', { type: 'button', 'aria-label': 'Increase quantity', text: '+', onclick() { apply(quantity + 1); render(); } }),
              ]),
              OT.h('button', { class: 'link-btn', type: 'button', text: 'Remove', 'aria-label': 'Remove ' + product.name, onclick() { OT.cart.remove(product.id); render(); } }),
            ]),
          ]),
          OT.h('div', { class: 'line-total', text: OT.peso(lineTotal) }),
        ]);
      })
    );
    const sum = lines.reduce((s, l) => s + l.total, 0);
    subtotal.textContent = OT.peso(sum);
    total.textContent = OT.peso(sum);
  }

  document.getElementById('clear').addEventListener('click', () => {
    if (window.confirm('Remove all items from your cart?')) {
      OT.cart.clear();
      render();
    }
  });

  OT.products()
    .then((list) => {
      products = list;
      render();
    })
    .catch((err) => {
      loadError.textContent = err.message;
      loadError.hidden = false;
    });
})();
