(function () {
  const form = document.getElementById('inquiry-form');
  const errorBox = document.getElementById('error');
  const success = document.getElementById('success');
  const submit = document.getElementById('submit');
  const details = document.getElementById('business-details');

  OT.api('/api/config')
    .then(({ business }) => {
      const rows = [
        ['Email', business.email],
        ['Phone', business.phone],
        ['Address', business.address],
      ].filter(([, value]) => value);
      details.replaceChildren(...rows.map(([label, value]) => OT.h('li', null, [OT.h('strong', { text: label }), value])));
    })
    .catch(() => {});

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    errorBox.hidden = true;
    success.hidden = true;
    if (!form.consent.checked) {
      errorBox.textContent = 'Please tick the consent box to agree to the Data Privacy Notice before sending your inquiry.';
      errorBox.hidden = false;
      return;
    }
    OT.setBusy(submit, true, 'Sending…');
    try {
      await OT.api('/api/inquiries', {
        method: 'POST',
        body: {
          name: form.name.value,
          email: form.email.value,
          phone: form.phone.value,
          subject: form.subject.value,
          message: form.message.value,
          consent: form.consent.checked,
          marketing: form.marketing.checked,
        },
      });
      const email = form.email.value.trim();
      form.reset();
      success.textContent = `Thank you! Your inquiry has been received. We will respond to ${email} as soon as possible.`;
      success.hidden = false;
      success.scrollIntoView({ block: 'center', behavior: 'smooth' });
    } catch (err) {
      errorBox.textContent = err.message;
      errorBox.hidden = false;
      errorBox.scrollIntoView({ block: 'center', behavior: 'smooth' });
    } finally {
      OT.setBusy(submit, false, 'Send Inquiry');
    }
  });
})();
