const path = require('path');
const { app, BrowserWindow, Menu, session, dialog } = require('electron');

const APP_NAME = 'Ocean Treasures';

app.setName(APP_NAME);
app.setPath('userData', path.join(app.getPath('appData'), APP_NAME));

let running = null;
let mainWindow = null;
let origin = '';

function isLocal(url) {
  try {
    return new URL(url).origin === origin;
  } catch {
    return false;
  }
}

function lockDownSession() {
  const ses = session.defaultSession;
  ses.webRequest.onBeforeRequest({ urls: ['http://*/*', 'https://*/*', 'ws://*/*', 'wss://*/*'] }, (details, callback) => {
    callback({ cancel: !isLocal(details.url) });
  });
  ses.setPermissionRequestHandler((_wc, _permission, callback) => callback(false));
  ses.setPermissionCheckHandler(() => false);
}

function buildMenu() {
  const go = (route) => () => {
    if (mainWindow) mainWindow.loadURL(origin + route);
  };
  const template = [
    {
      label: 'File',
      submenu: [{ role: 'quit', label: 'Exit' }],
    },
    {
      label: 'Go',
      submenu: [
        { label: 'Home', click: go('/') },
        { label: 'Shop', click: go('/shop') },
        { label: 'About Us', click: go('/about') },
        { label: 'Contact Us', click: go('/contact') },
        { label: 'Cart', click: go('/cart') },
        { type: 'separator' },
        { label: 'Staff Area', accelerator: 'CmdOrCtrl+Shift+A', click: go('/admin') },
      ],
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 380,
    minHeight: 600,
    title: APP_NAME,
    backgroundColor: '#f8f5ef',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      devTools: !app.isPackaged,
    },
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!isLocal(url)) event.preventDefault();
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!isLocal(url)) return { action: 'deny' };
    return {
      action: 'allow',
      overrideBrowserWindowOptions: {
        width: 900,
        height: 760,
        autoHideMenuBar: true,
        parent: mainWindow,
        title: APP_NAME,
        icon: path.join(__dirname, '..', 'build', 'icon.png'),
      },
    };
  });

  mainWindow.webContents.on('page-title-updated', (event) => {
    event.preventDefault();
  });

  mainWindow.loadURL(origin + '/');
}

async function boot() {
  const { startServer } = require('../server');
  try {
    running = await startServer({ dataDir: path.join(app.getPath('userData'), 'data') });
  } catch (err) {
    dialog.showErrorBox(APP_NAME, 'The application could not start its local service.\n\n' + err.message);
    app.exit(1);
    return;
  }
  origin = new URL(running.url).origin;
  lockDownSession();
  buildMenu();
  createWindow();
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(boot);

  app.on('window-all-closed', () => {
    app.quit();
  });

  app.on('before-quit', (event) => {
    if (!running) return;
    event.preventDefault();
    const finishing = running;
    running = null;
    finishing.stop().finally(() => app.quit());
  });
}
