const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('oceanTreasuresDesktop', {
  isDesktop: true,
  platform: process.platform,
});
