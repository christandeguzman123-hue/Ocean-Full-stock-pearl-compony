# Ocean Treasures – Offline Desktop Application

Ocean-inspired fine jewelry website packaged as an Electron desktop app for Windows. The website, product catalog, images, database and a local web server all live inside the app. No internet connection, browser or manual server start is needed.

## What is inside

| Folder | Purpose |
| --- | --- |
| `electron/` | Electron main process and preload script |
| `server/` | Local HTTP server (127.0.0.1 only), SQLite database, admin authentication, validation |
| `public/` | Website pages, CSS, JavaScript, logo and all 16 product photos |
| `build/` | Windows icon files used by the installer |
| `scripts/test.js` | Automated server/database test suite |

Pages: Home, Shop (search, category filter, sort, product details), About Us, Contact Us, Cart, Checkout with order confirmation, Data Privacy Notice, and a Staff Area (`/admin`).

## Build the Windows installer and portable app

Requirements on a Windows PC (internet is needed once, to download build tools): Node.js 22.13 or newer.

```
npm install
npm run dist
```

Output in `dist/`:

- `Ocean-Treasures-Setup-1.0.0.exe` – installer (choose install folder, desktop and Start Menu shortcuts)
- `Ocean-Treasures-Portable-1.0.0.exe` – portable single executable, no installation

Other commands: `npm run dist:installer`, `npm run dist:portable`, `npm start` (run in Electron without packaging), `npm run server` (run only the local server, then open the printed address in a browser), `npm test`.

## Using the app

1. Install and open **Ocean Treasures**. The website appears in its own window.
2. Open the staff area from the footer link **Staff Login** or the menu **Go > Staff Area** (Ctrl+Shift+A).
3. On the very first visit you create the administrator account (username plus a password of at least 10 characters with letters and numbers). There is no default password.
4. In the staff area you review orders and inquiries, change order or inquiry status, delete records no longer needed, and change your password.

## Where data is stored

Everything is stored locally in `%APPDATA%\Ocean Treasures\data\ocean-treasures.db` (SQLite). Records survive closing and reopening the app, and they are kept when the app is uninstalled. To move to another computer, copy that file to the same location there. Treat it as confidential because it holds customer information.

## Optional settings

To show the business email, phone and address on the Contact page, copy `.env.example` to `%APPDATA%\Ocean Treasures\data\.env` and fill in the values. No contact details are shown unless you set them, since none were given in the documentation.

## Privacy and security

- Server listens only on 127.0.0.1 and rejects requests with other Host headers or other origins.
- Content Security Policy allows only local resources; the Electron window also blocks every non-local network request.
- Order totals are always recalculated on the server from the stored prices.
- Only name, email, contact number, delivery address (orders) and the message are collected. Consent (with timestamp) is required; promotional updates are a separate optional checkbox.
- Admin passwords are hashed (scrypt), sessions use HttpOnly SameSite cookies, and five failed sign-ins lock login for 15 minutes.
- Application logs never contain customer data.
- Admins can delete an order or inquiry to honor deletion requests under RA 10173.

## Notes

- Checkout is an order inquiry: no payment is taken online. The business contacts the customer to confirm availability, delivery fee and payment, as described in the documentation.
- The Windows build must be created on Windows (or on Linux with Wine installed).
- The SQLite database uses Node's built-in `node:sqlite` module, so no native add-ons need compiling. Electron 38 bundles a Node version that includes it.
