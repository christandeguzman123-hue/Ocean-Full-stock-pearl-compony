const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');
const assert = require('assert');
const { startServer } = require('../server');

const EXPECTED = [
  ['Stella Maris Open Ring', 599],
  ['Enchanted Flora & Pearl Stacking Set', 899],
  ['Botanical Dewdrop Stack Ring', 749],
  ["Mermaid's Fan Open Cuff Ring", 1299],
  ['Seashell Whispers Accent Band', 449],
  ['Treasures of the Deep Pearl Bracelet', 1099],
  ["Siren's Call Baroque Pearl Bracelet", 699],
  ['Sirena Coastal Pearl Hair Combs (5 pieces)', 999],
  ['Starlight Ocean Teardrop Earrings', 699],
  ['Mother-of-Pearl Scallop Statement Earrings', 699],
  ['Wire-Wrapped Crystal & Mermaid Tail Pendant', 699],
  ['Deep Blue Sea Beaded Charm Choker', 799],
  ['Sea Glass & Shell Delicate Bracelet', 499],
  ['Natural Seashell & Pearl Strand Bracelet', 599],
  ['Nautical Charm Necklace & Bracelet Set', 899],
  ['Crystal Starfish Bridal Jewelry Set', 1199],
];

let passed = 0;
async function check(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log('  ok   ' + name);
  } catch (err) {
    console.error('  FAIL ' + name + '\n       ' + err.message);
    process.exitCode = 1;
  }
}

async function call(base, method, url, body, cookie, extraHeaders) {
  const headers = { ...(extraHeaders || {}) };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (cookie) headers.Cookie = cookie;
  const res = await fetch(base + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  let data = null;
  const type = res.headers.get('content-type') || '';
  if (type.includes('json')) data = await res.json();
  return { res, data, cookie: (res.headers.get('set-cookie') || '').split(';')[0] };
}

const validOrder = (items) => ({
  name: 'Maria Santos',
  email: 'maria@example.com',
  phone: '+63 917 123 4567',
  address: '12 Coral Street, Barangay Pearl, Manila',
  notes: '',
  consent: true,
  marketing: false,
  items,
});

(async () => {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ot-test-'));
  let server = await startServer({ dataDir, port: 0 });
  let base = server.url;
  console.log('Testing against ' + base);

  await check('all pages are served', async () => {
    for (const p of ['/', '/shop', '/about', '/contact', '/cart', '/checkout', '/privacy', '/admin', '/shop.html']) {
      const { res } = await call(base, 'GET', p);
      assert.strictEqual(res.status, 200, p + ' returned ' + res.status);
    }
    assert.strictEqual((await call(base, 'GET', '/missing')).res.status, 404);
  });

  await check('all 16 products with exact names and prices', async () => {
    const { data } = await call(base, 'GET', '/api/products');
    assert.strictEqual(data.length, 16);
    EXPECTED.forEach(([name, price], i) => {
      assert.strictEqual(data[i].name, name);
      assert.strictEqual(data[i].price, price, name);
    });
  });

  await check('every product image is served', async () => {
    const { data } = await call(base, 'GET', '/api/products');
    for (const p of data) {
      const { res } = await call(base, 'GET', p.image);
      assert.strictEqual(res.status, 200, p.image);
      assert.strictEqual(res.headers.get('content-type'), 'image/jpeg');
    }
    assert.strictEqual((await call(base, 'GET', '/images/logo.png')).res.status, 200);
  });

  await check('path traversal and dotfiles are blocked', async () => {
    for (const p of ['/../package.json', '/%2e%2e/package.json', '/js/../../server/db.js', '/.env', '/css/%2e%2e%2f%2e%2e%2fpackage.json']) {
      const { res } = await call(base, 'GET', p);
      assert.notStrictEqual(res.status, 200, p);
    }
  });

  await check('requests with a foreign Host header are rejected', async () => {
    const status = await new Promise((resolve, reject) => {
      const url = new URL(base);
      const req = http.request(
        { host: url.hostname, port: url.port, path: '/api/products', headers: { Host: 'evil.example.com' } },
        (res) => {
          res.resume();
          resolve(res.statusCode);
        }
      );
      req.on('error', reject);
      req.end();
    });
    assert.strictEqual(status, 403);
  });

  await check('cross-origin writes are rejected', async () => {
    const { res } = await call(base, 'POST', '/api/inquiries', { x: 1 }, undefined, { Origin: 'http://evil.example.com' });
    assert.strictEqual(res.status, 403);
  });

  await check('security headers are present', async () => {
    const { res } = await call(base, 'GET', '/');
    assert.ok(res.headers.get('content-security-policy').includes("default-src 'self'"));
    assert.strictEqual(res.headers.get('x-content-type-options'), 'nosniff');
  });

  let reference;
  await check('order totals are computed by the server', async () => {
    const { res, data } = await call(base, 'POST', '/api/orders', {
      ...validOrder([{ id: 1, quantity: 2 }, { id: 16, quantity: 1 }, { id: 1, quantity: 1 }]),
      price: 1,
      subtotal: 1,
    });
    assert.strictEqual(res.status, 201);
    assert.strictEqual(data.subtotal, 599 * 3 + 1199);
    assert.match(data.reference, /^OT-\d{8}-[A-Z0-9]{5}$/);
    assert.strictEqual(data.items.length, 2);
    reference = data.reference;
  });

  await check('orders reject missing consent, bad input and unknown products', async () => {
    const bad = [
      { ...validOrder([{ id: 1, quantity: 1 }]), consent: false },
      { ...validOrder([]) },
      { ...validOrder([{ id: 1, quantity: 0 }]) },
      { ...validOrder([{ id: 1, quantity: 21 }]) },
      { ...validOrder([{ id: 999, quantity: 1 }]) },
      { ...validOrder([{ id: 1, quantity: 1 }]), email: 'not-an-email' },
      { ...validOrder([{ id: 1, quantity: 1 }]), phone: 'abc' },
      { ...validOrder([{ id: 1, quantity: 1 }]), address: 'short' },
    ];
    for (const body of bad) {
      const { res } = await call(base, 'POST', '/api/orders', body);
      assert.strictEqual(res.status, 400, JSON.stringify(body).slice(0, 80));
    }
    const wrongType = await fetch(base + '/api/orders', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: '{}' });
    assert.strictEqual(wrongType.status, 415);
  });

  await check('inquiry submission works and requires consent', async () => {
    const body = { name: 'Juan Dela Cruz', email: 'juan@example.com', phone: '', subject: 'Product inquiry', message: 'Is the Stella Maris ring available in silver?', consent: true, marketing: true };
    const ok = await call(base, 'POST', '/api/inquiries', body);
    assert.strictEqual(ok.res.status, 201);
    const no = await call(base, 'POST', '/api/inquiries', { ...body, consent: false });
    assert.strictEqual(no.res.status, 400);
  });

  await check('admin endpoints require authentication', async () => {
    for (const p of ['/api/admin/orders', '/api/admin/inquiries']) {
      assert.strictEqual((await call(base, 'GET', p)).res.status, 401);
    }
    assert.strictEqual((await call(base, 'PATCH', '/api/admin/orders/1', { status: 'Paid' })).res.status, 401);
  });

  let cookie;
  await check('first-run admin setup enforces a strong password and happens once', async () => {
    const status = await call(base, 'GET', '/api/admin/status');
    assert.strictEqual(status.data.setupRequired, true);
    const weak = await call(base, 'POST', '/api/admin/setup', { username: 'owner', password: 'short1' });
    assert.strictEqual(weak.res.status, 400);
    const ok = await call(base, 'POST', '/api/admin/setup', { username: 'owner', password: 'Pearl-Secure-2026' });
    assert.strictEqual(ok.res.status, 201);
    assert.ok(/HttpOnly/i.test(ok.res.headers.get('set-cookie')));
    cookie = ok.cookie;
    const again = await call(base, 'POST', '/api/admin/setup', { username: 'other', password: 'Another-Pass-2026' });
    assert.strictEqual(again.res.status, 409);
  });

  await check('admin can review and update order and inquiry status', async () => {
    const orders = (await call(base, 'GET', '/api/admin/orders', undefined, cookie)).data;
    assert.strictEqual(orders.length, 1);
    assert.strictEqual(orders[0].reference, reference);
    assert.strictEqual(orders[0].items.length, 2);
    const bad = await call(base, 'PATCH', `/api/admin/orders/${orders[0].id}`, { status: 'Hacked' }, cookie);
    assert.strictEqual(bad.res.status, 400);
    const patch = await call(base, 'PATCH', `/api/admin/orders/${orders[0].id}`, { status: 'Confirmed' }, cookie);
    assert.strictEqual(patch.res.status, 200);
    const after = (await call(base, 'GET', '/api/admin/orders', undefined, cookie)).data;
    assert.strictEqual(after[0].status, 'Confirmed');
    const inquiries = (await call(base, 'GET', '/api/admin/inquiries', undefined, cookie)).data;
    assert.strictEqual(inquiries.length, 1);
    assert.ok(inquiries[0].consentAt);
    const p2 = await call(base, 'PATCH', `/api/admin/inquiries/${inquiries[0].id}`, { status: 'Responded' }, cookie);
    assert.strictEqual(p2.res.status, 200);
  });

  await check('login rejects wrong passwords and locks out after repeated failures', async () => {
    const logout = await call(base, 'POST', '/api/admin/logout', {}, cookie);
    assert.strictEqual(logout.res.status, 200);
    assert.strictEqual((await call(base, 'GET', '/api/admin/orders', undefined, cookie)).res.status, 401);
    for (let i = 0; i < 5; i += 1) {
      const r = await call(base, 'POST', '/api/admin/login', { username: 'owner', password: 'wrong-password-' + i });
      assert.strictEqual(r.res.status, 401);
    }
    const locked = await call(base, 'POST', '/api/admin/login', { username: 'owner', password: 'Pearl-Secure-2026' });
    assert.strictEqual(locked.res.status, 429);
  });

  await check('records persist after the application restarts', async () => {
    await server.stop();
    server = await startServer({ dataDir, port: 0 });
    base = server.url;
    const status = await call(base, 'GET', '/api/admin/status');
    assert.strictEqual(status.data.setupRequired, false);
    const login = await call(base, 'POST', '/api/admin/login', { username: 'owner', password: 'Pearl-Secure-2026' });
    assert.strictEqual(login.res.status, 200);
    const orders = (await call(base, 'GET', '/api/admin/orders', undefined, login.cookie)).data;
    assert.strictEqual(orders.length, 1);
    assert.strictEqual(orders[0].reference, reference);
    assert.strictEqual(orders[0].status, 'Confirmed');
    assert.strictEqual((await call(base, 'GET', '/api/admin/inquiries', undefined, login.cookie)).data.length, 1);
    assert.strictEqual((await call(base, 'GET', '/api/products')).data.length, 16);
  });

  await check('admin can change password and delete records', async () => {
    const login = await call(base, 'POST', '/api/admin/login', { username: 'owner', password: 'Pearl-Secure-2026' });
    const wrong = await call(base, 'POST', '/api/admin/password', { currentPassword: 'nope', newPassword: 'Brand-New-Pass-77' }, login.cookie);
    assert.strictEqual(wrong.res.status, 400);
    const ok = await call(base, 'POST', '/api/admin/password', { currentPassword: 'Pearl-Secure-2026', newPassword: 'Brand-New-Pass-77' }, login.cookie);
    assert.strictEqual(ok.res.status, 200);
    const relogin = await call(base, 'POST', '/api/admin/login', { username: 'owner', password: 'Brand-New-Pass-77' });
    assert.strictEqual(relogin.res.status, 200);
    const orders = (await call(base, 'GET', '/api/admin/orders', undefined, relogin.cookie)).data;
    assert.strictEqual((await call(base, 'DELETE', `/api/admin/orders/${orders[0].id}`, undefined, relogin.cookie)).res.status, 200);
    assert.strictEqual((await call(base, 'GET', '/api/admin/orders', undefined, relogin.cookie)).data.length, 0);
  });

  await check('database stores no plaintext password', async () => {
    const buf = fs.readFileSync(path.join(dataDir, 'ocean-treasures.db'));
    assert.ok(!buf.includes('Brand-New-Pass-77'));
    assert.ok(!buf.includes('Pearl-Secure-2026'));
  });

  await check('no remote resources are referenced by the website files', async () => {
    const root = path.join(__dirname, '..', 'public');
    const offenders = [];
    (function walk(dir) {
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) walk(full);
        else if (/\.(html|css|js|svg)$/.test(entry.name)) {
          const text = fs.readFileSync(full, 'utf8').replace(/xmlns="http:\/\/www\.w3\.org\/2000\/svg"/g, '');
          const hits = text.match(/(?:src|href|url\()\s*=?\s*["']?(?:https?:)?\/\/[^"')\s]+/g);
          if (hits) offenders.push(entry.name + ': ' + hits.join(', '));
        }
      }
    })(root);
    assert.deepStrictEqual(offenders, []);
  });

  await server.stop();
  fs.rmSync(dataDir, { recursive: true, force: true });
  console.log(`\n${passed} checks passed${process.exitCode ? ', with failures' : ''}`);
})();
