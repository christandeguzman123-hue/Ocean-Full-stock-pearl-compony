const fs = require('fs');
const path = require('path');
const http = require('http');
const auth = require('./auth');
const validate = require('./validate');
const { ORDER_STATUSES, INQUIRY_STATUSES } = require('./db');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

const PAGES = {
  '/': 'index.html',
  '/shop': 'shop.html',
  '/about': 'about.html',
  '/contact': 'contact.html',
  '/cart': 'cart.html',
  '/checkout': 'checkout.html',
  '/privacy': 'privacy.html',
  '/admin': 'admin.html',
};

const SECURITY_HEADERS = {
  'Content-Security-Policy':
    "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Cross-Origin-Resource-Policy': 'same-origin',
};

function createApp(config, db) {
  const sessions = auth.createSessions(config.sessionMinutes);
  let allowedHosts = new Set();

  function setPort(port) {
    allowedHosts = new Set([`127.0.0.1:${port}`, `localhost:${port}`]);
  }

  function send(res, status, body, headers = {}) {
    res.writeHead(status, { ...SECURITY_HEADERS, ...headers });
    res.end(body);
  }

  function json(res, status, data, headers = {}) {
    send(res, status, JSON.stringify(data), {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...headers,
    });
  }

  function readBody(req) {
    return new Promise((resolve, reject) => {
      const type = String(req.headers['content-type'] || '');
      if (!type.toLowerCase().startsWith('application/json')) {
        const err = new Error('Unsupported content type.');
        err.status = 415;
        err.expose = true;
        reject(err);
        req.resume();
        return;
      }
      const chunks = [];
      let size = 0;
      req.on('data', (chunk) => {
        size += chunk.length;
        if (size > 65536) {
          const err = new Error('Request is too large.');
          err.status = 413;
          err.expose = true;
          reject(err);
          req.destroy();
          return;
        }
        chunks.push(chunk);
      });
      req.on('end', () => {
        try {
          const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
          if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('bad');
          resolve(parsed);
        } catch {
          reject(validate.fail('Request body is not valid JSON.'));
        }
      });
      req.on('error', reject);
    });
  }

  function currentSession(req) {
    return sessions.get(auth.readCookie(req.headers.cookie, auth.SESSION_COOKIE));
  }

  function sameOrigin(req) {
    const origin = req.headers.origin;
    if (!origin) return true;
    try {
      return allowedHosts.has(new URL(origin).host);
    } catch {
      return false;
    }
  }

  function clientKey(req) {
    return req.socket.remoteAddress || 'local';
  }

  async function handleApi(req, res, pathname) {
    const method = req.method;

    if (method === 'GET' && pathname === '/api/products') {
      return json(res, 200, db.listProducts());
    }

    if (method === 'GET' && pathname === '/api/config') {
      return json(res, 200, { business: config.business });
    }

    if (method === 'POST' && pathname === '/api/orders') {
      const parsed = validate.order(await readBody(req));
      const created = db.createOrder(parsed.customer, parsed.items);
      return json(res, 201, created);
    }

    if (method === 'POST' && pathname === '/api/inquiries') {
      const created = db.createInquiry(validate.inquiry(await readBody(req)));
      return json(res, 201, created);
    }

    if (method === 'GET' && pathname === '/api/admin/status') {
      const session = currentSession(req);
      return json(res, 200, {
        setupRequired: !db.hasAdmin(),
        authenticated: Boolean(session),
        username: session ? session.username : null,
        orderStatuses: ORDER_STATUSES,
        inquiryStatuses: INQUIRY_STATUSES,
      });
    }

    if (method === 'POST' && pathname === '/api/admin/setup') {
      if (db.hasAdmin()) return json(res, 409, { error: 'An administrator account already exists.' });
      const { username, password } = validate.credentials(await readBody(req));
      const problem = auth.passwordProblem(password);
      if (problem) return json(res, 400, { error: problem });
      const id = db.createAdmin(username, auth.hashPassword(password));
      const token = sessions.create({ id, username });
      return json(res, 201, { ok: true }, { 'Set-Cookie': sessions.cookie(token, sessions.ttlSeconds) });
    }

    if (method === 'POST' && pathname === '/api/admin/login') {
      const key = clientKey(req);
      if (sessions.isLocked(key)) {
        return json(res, 429, { error: 'Too many failed attempts. Please try again in 15 minutes.' });
      }
      const body = await readBody(req);
      const username = typeof body.username === 'string' ? body.username.trim() : '';
      const password = typeof body.password === 'string' ? body.password : '';
      const admin = db.getAdminByName(username);
      const ok = admin && password.length <= 128 && auth.verifyPassword(password, admin.password_hash);
      if (!ok) {
        sessions.recordFailure(key);
        return json(res, 401, { error: 'Incorrect username or password.' });
      }
      sessions.clearFailures(key);
      const token = sessions.create(admin);
      return json(res, 200, { ok: true }, { 'Set-Cookie': sessions.cookie(token, sessions.ttlSeconds) });
    }

    const session = pathname.startsWith('/api/admin/') ? currentSession(req) : null;
    if (pathname.startsWith('/api/admin/') && !session) {
      return json(res, 401, { error: 'Please sign in.' });
    }

    if (method === 'POST' && pathname === '/api/admin/logout') {
      sessions.destroy(auth.readCookie(req.headers.cookie, auth.SESSION_COOKIE));
      return json(res, 200, { ok: true }, { 'Set-Cookie': sessions.cookie('', 0) });
    }

    if (method === 'POST' && pathname === '/api/admin/password') {
      const body = await readBody(req);
      const admin = db.getAdminById(session.adminId);
      const current = typeof body.currentPassword === 'string' ? body.currentPassword : '';
      if (!admin || current.length > 128 || !auth.verifyPassword(current, admin.password_hash)) {
        return json(res, 400, { error: 'Current password is incorrect.' });
      }
      const problem = auth.passwordProblem(body.newPassword);
      if (problem) return json(res, 400, { error: problem });
      db.setAdminPassword(admin.id, auth.hashPassword(body.newPassword));
      sessions.destroyForAdmin(admin.id, auth.readCookie(req.headers.cookie, auth.SESSION_COOKIE));
      return json(res, 200, { ok: true });
    }

    if (method === 'GET' && pathname === '/api/admin/orders') return json(res, 200, db.listOrders());
    if (method === 'GET' && pathname === '/api/admin/inquiries') return json(res, 200, db.listInquiries());

    const match = /^\/api\/admin\/(orders|inquiries)\/(\d+)$/.exec(pathname);
    if (match) {
      const kind = match[1];
      const id = Number(match[2]);
      if (method === 'PATCH') {
        const body = await readBody(req);
        const allowed = kind === 'orders' ? ORDER_STATUSES : INQUIRY_STATUSES;
        if (!allowed.includes(body.status)) return json(res, 400, { error: 'Invalid status.' });
        const done = kind === 'orders' ? db.setOrderStatus(id, body.status) : db.setInquiryStatus(id, body.status);
        return done ? json(res, 200, { ok: true }) : json(res, 404, { error: 'Record not found.' });
      }
      if (method === 'DELETE') {
        const done = kind === 'orders' ? db.deleteOrder(id) : db.deleteInquiry(id);
        return done ? json(res, 200, { ok: true }) : json(res, 404, { error: 'Record not found.' });
      }
    }

    return json(res, 404, { error: 'Not found.' });
  }

  function serveStatic(req, res, pathname) {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      return send(res, 405, 'Method not allowed', { Allow: 'GET, HEAD' });
    }
    let rel;
    if (Object.prototype.hasOwnProperty.call(PAGES, pathname)) rel = PAGES[pathname];
    else rel = pathname.replace(/^\/+/, '');

    let decoded;
    try {
      decoded = decodeURIComponent(rel);
    } catch {
      return send(res, 400, 'Bad request');
    }
    const parts = decoded.split(/[\\/]+/);
    if (parts.some((p) => p === '..' || p.startsWith('.')) || decoded.includes('\0')) {
      return send(res, 404, 'Not found');
    }
    const file = path.join(config.publicDir, ...parts);
    if (!file.startsWith(config.publicDir + path.sep)) return send(res, 404, 'Not found');

    const type = MIME[path.extname(file).toLowerCase()];
    if (!type) return notFound(res);

    fs.readFile(file, (err, data) => {
      if (err) return notFound(res);
      const isHtml = type.startsWith('text/html');
      send(res, 200, req.method === 'HEAD' ? undefined : data, {
        'Content-Type': type,
        'Content-Length': data.length,
        'Cache-Control': isHtml ? 'no-store' : 'no-cache',
      });
    });
  }

  function notFound(res) {
    fs.readFile(path.join(config.publicDir, '404.html'), (err, data) => {
      if (err) return send(res, 404, 'Not found');
      send(res, 404, data, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-store' });
    });
  }

  const handler = async (req, res) => {
    try {
      if (!allowedHosts.has(String(req.headers.host || '').toLowerCase())) {
        return send(res, 403, 'Forbidden');
      }
      const pathname = new URL(req.url, 'http://localhost').pathname;
      if (pathname.startsWith('/api/')) {
        if (req.method !== 'GET' && !sameOrigin(req)) return json(res, 403, { error: 'Forbidden.' });
        return await handleApi(req, res, pathname);
      }
      return serveStatic(req, res, pathname);
    } catch (err) {
      if (err && err.expose) return json(res, err.status || 400, { error: err.message });
      if (err && err.status === 400) return json(res, 400, { error: err.message });
      console.error('Request failed:', err && err.message);
      if (!res.headersSent) return json(res, 500, { error: 'Something went wrong. Please try again.' });
    }
  };

  return { handler, setPort };
}

function start(config, db) {
  const app = createApp(config, db);
  const server = http.createServer(app.handler);
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;

  return new Promise((resolve, reject) => {
    const attempt = (port) => {
      const onError = (err) => {
        if (err.code === 'EADDRINUSE' && port !== 0) attempt(0);
        else reject(err);
      };
      server.once('error', onError);
      server.listen(port, config.host, () => {
        server.removeListener('error', onError);
        const actual = server.address().port;
        app.setPort(actual);
        resolve({
          server,
          port: actual,
          url: `http://127.0.0.1:${actual}`,
          close: () => new Promise((r) => server.close(() => r())),
        });
      });
    };
    attempt(config.port);
  });
}

module.exports = { start, createApp };
