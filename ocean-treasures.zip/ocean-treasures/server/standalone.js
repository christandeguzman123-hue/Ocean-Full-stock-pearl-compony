const { startServer } = require('./index');

startServer()
  .then((running) => {
    console.log(`Ocean Treasures is running at ${running.url}`);
    console.log(`Data folder: ${running.dataDir}`);
    const shutdown = () => {
      running.stop().finally(() => process.exit(0));
    };
    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);
  })
  .catch((err) => {
    console.error('Could not start the server:', err.message);
    process.exit(1);
  });
