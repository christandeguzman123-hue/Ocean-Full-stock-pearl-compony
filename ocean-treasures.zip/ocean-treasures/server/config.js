const fs = require('fs');
const path = require('path');

function parseEnv(text) {
  const out = {};
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    out[key] = value;
  }
  return out;
}

function loadEnvFiles(files) {
  for (const file of files) {
    try {
      const parsed = parseEnv(fs.readFileSync(file, 'utf8'));
      for (const [key, value] of Object.entries(parsed)) {
        if (process.env[key] === undefined) process.env[key] = value;
      }
    } catch (err) {
      if (err.code !== 'ENOENT') throw err;
    }
  }
}

function toInt(value, fallback, min, max) {
  const n = Number.parseInt(value, 10);
  if (!Number.isFinite(n) || n < min || n > max) return fallback;
  return n;
}

function load(options = {}) {
  const root = path.resolve(__dirname, '..');
  const dataDir = path.resolve(options.dataDir || process.env.DATA_DIR || path.join(root, 'data'));
  loadEnvFiles([path.join(dataDir, '.env'), path.join(root, '.env')]);

  return {
    root,
    host: '127.0.0.1',
    port: toInt(options.port ?? process.env.PORT, 38417, 0, 65535),
    dataDir: path.resolve(options.dataDir || process.env.DATA_DIR || dataDir),
    publicDir: path.join(root, 'public'),
    seedFile: path.join(__dirname, 'seed', 'products.json'),
    sessionMinutes: toInt(process.env.SESSION_MINUTES, 60, 5, 1440),
    business: {
      name: 'Ocean Treasures',
      email: (process.env.BUSINESS_EMAIL || '').trim(),
      phone: (process.env.BUSINESS_PHONE || '').trim(),
      address: (process.env.BUSINESS_ADDRESS || '').trim(),
    },
  };
}

module.exports = { load, parseEnv };
