const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const ORDER_STATUSES = ['New', 'Contacted', 'Confirmed', 'Paid', 'Shipped', 'Completed', 'Cancelled'];
const INQUIRY_STATUSES = ['New', 'Responded', 'Closed'];
const REF_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price INTEGER NOT NULL CHECK (price >= 0),
  description TEXT NOT NULL,
  benefit TEXT NOT NULL,
  image TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reference TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  subtotal INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'New',
  consent_at TEXT NOT NULL,
  marketing_opt_in INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  unit_price INTEGER NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0)
);
CREATE TABLE IF NOT EXISTS inquiries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  subject TEXT NOT NULL DEFAULT '',
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'New',
  consent_at TEXT NOT NULL,
  marketing_opt_in INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
CREATE INDEX IF NOT EXISTS idx_inquiries_created ON inquiries(created_at);
`;

function now() {
  return new Date().toISOString();
}

function makeReference() {
  const d = new Date();
  const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const bytes = crypto.randomBytes(5);
  let suffix = '';
  for (const b of bytes) suffix += REF_ALPHABET[b % REF_ALPHABET.length];
  return `OT-${stamp}-${suffix}`;
}

function open(config) {
  fs.mkdirSync(config.dataDir, { recursive: true });
  const db = new DatabaseSync(path.join(config.dataDir, 'ocean-treasures.db'));
  db.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);

  const seed = JSON.parse(fs.readFileSync(config.seedFile, 'utf8'));
  const existing = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
  if (existing === 0) {
    const insert = db.prepare(
      'INSERT INTO products (id, name, category, price, description, benefit, image) VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    transaction(db, () => {
      for (const p of seed) {
        insert.run(
          p.id,
          p.name,
          p.category,
          p.price,
          p.description,
          p.benefit,
          `/images/products/product-${String(p.id).padStart(2, '0')}.jpg`
        );
      }
    });
  }

  const q = {
    products: db.prepare('SELECT id, name, category, price, description, benefit, image FROM products ORDER BY id'),
    productById: db.prepare('SELECT id, name, price FROM products WHERE id = ?'),
    insertOrder: db.prepare(
      `INSERT INTO orders (reference, customer_name, email, phone, address, notes, subtotal, status, consent_at, marketing_opt_in, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'New', ?, ?, ?, ?)`
    ),
    insertItem: db.prepare(
      'INSERT INTO order_items (order_id, product_id, name, unit_price, quantity) VALUES (?, ?, ?, ?, ?)'
    ),
    orders: db.prepare('SELECT * FROM orders ORDER BY id DESC'),
    orderItems: db.prepare('SELECT product_id, name, unit_price, quantity FROM order_items WHERE order_id = ? ORDER BY id'),
    orderById: db.prepare('SELECT id FROM orders WHERE id = ?'),
    updateOrder: db.prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?'),
    deleteOrder: db.prepare('DELETE FROM orders WHERE id = ?'),
    insertInquiry: db.prepare(
      `INSERT INTO inquiries (name, email, phone, subject, message, status, consent_at, marketing_opt_in, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'New', ?, ?, ?, ?)`
    ),
    inquiries: db.prepare('SELECT * FROM inquiries ORDER BY id DESC'),
    inquiryById: db.prepare('SELECT id FROM inquiries WHERE id = ?'),
    updateInquiry: db.prepare('UPDATE inquiries SET status = ?, updated_at = ? WHERE id = ?'),
    deleteInquiry: db.prepare('DELETE FROM inquiries WHERE id = ?'),
    adminCount: db.prepare('SELECT COUNT(*) AS n FROM admins'),
    adminByName: db.prepare('SELECT id, username, password_hash FROM admins WHERE username = ?'),
    adminById: db.prepare('SELECT id, username, password_hash FROM admins WHERE id = ?'),
    insertAdmin: db.prepare('INSERT INTO admins (username, password_hash, created_at) VALUES (?, ?, ?)'),
    updateAdminPassword: db.prepare('UPDATE admins SET password_hash = ? WHERE id = ?'),
  };

  const toOrder = (row) => ({
    id: row.id,
    reference: row.reference,
    customerName: row.customer_name,
    email: row.email,
    phone: row.phone,
    address: row.address,
    notes: row.notes,
    subtotal: row.subtotal,
    status: row.status,
    marketingOptIn: row.marketing_opt_in === 1,
    consentAt: row.consent_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    items: q.orderItems.all(row.id).map((i) => ({
      productId: i.product_id,
      name: i.name,
      unitPrice: i.unit_price,
      quantity: i.quantity,
    })),
  });

  const toInquiry = (row) => ({
    id: row.id,
    name: row.name,
    email: row.email,
    phone: row.phone,
    subject: row.subject,
    message: row.message,
    status: row.status,
    marketingOptIn: row.marketing_opt_in === 1,
    consentAt: row.consent_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  });

  return {
    close: () => db.close(),
    listProducts: () => q.products.all().map((p) => ({ ...p })),

    createOrder(customer, items) {
      return transaction(db, () => {
        let subtotal = 0;
        const lines = [];
        for (const item of items) {
          const product = q.productById.get(item.productId);
          if (!product) {
            const err = new Error('One or more products are no longer available.');
            err.status = 400;
            throw err;
          }
          subtotal += product.price * item.quantity;
          lines.push({ productId: product.id, name: product.name, unitPrice: product.price, quantity: item.quantity });
        }
        const stamp = now();
        let reference;
        let orderId;
        for (let attempt = 0; attempt < 5; attempt += 1) {
          reference = makeReference();
          try {
            orderId = q.insertOrder.run(
              reference,
              customer.name,
              customer.email,
              customer.phone,
              customer.address,
              customer.notes,
              subtotal,
              stamp,
              customer.marketingOptIn ? 1 : 0,
              stamp,
              stamp
            ).lastInsertRowid;
            break;
          } catch (err) {
            if (!/UNIQUE/i.test(err.message) || attempt === 4) throw err;
          }
        }
        for (const line of lines) {
          q.insertItem.run(orderId, line.productId, line.name, line.unitPrice, line.quantity);
        }
        return { reference, status: 'New', subtotal, items: lines, createdAt: stamp };
      });
    },

    listOrders: () => q.orders.all().map(toOrder),
    setOrderStatus(id, status) {
      if (!q.orderById.get(id)) return false;
      q.updateOrder.run(status, now(), id);
      return true;
    },
    deleteOrder: (id) => q.deleteOrder.run(id).changes > 0,

    createInquiry(data) {
      const stamp = now();
      q.insertInquiry.run(
        data.name,
        data.email,
        data.phone,
        data.subject,
        data.message,
        stamp,
        data.marketingOptIn ? 1 : 0,
        stamp,
        stamp
      );
      return { status: 'New', createdAt: stamp };
    },
    listInquiries: () => q.inquiries.all().map(toInquiry),
    setInquiryStatus(id, status) {
      if (!q.inquiryById.get(id)) return false;
      q.updateInquiry.run(status, now(), id);
      return true;
    },
    deleteInquiry: (id) => q.deleteInquiry.run(id).changes > 0,

    hasAdmin: () => q.adminCount.get().n > 0,
    getAdminByName: (username) => q.adminByName.get(username),
    getAdminById: (id) => q.adminById.get(id),
    createAdmin: (username, passwordHash) =>
      Number(q.insertAdmin.run(username, passwordHash, now()).lastInsertRowid),
    setAdminPassword: (id, passwordHash) => q.updateAdminPassword.run(passwordHash, id),
  };
}

function transaction(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

module.exports = { open, ORDER_STATUSES, INQUIRY_STATUSES };
