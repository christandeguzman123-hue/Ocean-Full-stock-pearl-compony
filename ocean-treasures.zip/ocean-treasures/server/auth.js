const crypto = require('crypto');

const SESSION_COOKIE = 'ot_admin';
const MAX_FAILURES = 5;
const LOCK_MS = 15 * 60 * 1000;

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

function verifyPassword(password, stored) {
  const parts = String(stored).split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const salt = Buffer.from(parts[1], 'base64');
  const expected = Buffer.from(parts[2], 'base64');
  const actual = crypto.scryptSync(password, salt, expected.length);
  return crypto.timingSafeEqual(actual, expected);
}

function passwordProblem(password) {
  if (typeof password !== 'string' || password.length < 10) return 'Password must be at least 10 characters long.';
  if (password.length > 128) return 'Password is too long.';
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) return 'Password must contain letters and numbers.';
  return null;
}

function createSessions(minutes) {
  const ttl = minutes * 60 * 1000;
  const sessions = new Map();
  const failures = new Map();

  function sweep() {
    const t = Date.now();
    for (const [token, s] of sessions) if (s.expires <= t) sessions.delete(token);
  }

  return {
    create(admin) {
      sweep();
      const token = crypto.randomBytes(32).toString('hex');
      sessions.set(token, { adminId: admin.id, username: admin.username, expires: Date.now() + ttl });
      return token;
    },
    get(token) {
      if (!token) return null;
      const s = sessions.get(token);
      if (!s) return null;
      if (s.expires <= Date.now()) {
        sessions.delete(token);
        return null;
      }
      s.expires = Date.now() + ttl;
      return s;
    },
    destroy(token) {
      sessions.delete(token);
    },
    destroyForAdmin(adminId, exceptToken) {
      for (const [token, s] of sessions) if (s.adminId === adminId && token !== exceptToken) sessions.delete(token);
    },
    isLocked(key) {
      const f = failures.get(key);
      if (!f) return false;
      if (f.until && f.until > Date.now()) return true;
      if (f.until) failures.delete(key);
      return false;
    },
    recordFailure(key) {
      const f = failures.get(key) || { count: 0, until: 0 };
      f.count += 1;
      if (f.count >= MAX_FAILURES) {
        f.until = Date.now() + LOCK_MS;
        f.count = 0;
      }
      failures.set(key, f);
    },
    clearFailures(key) {
      failures.delete(key);
    },
    cookie(token, maxAgeSeconds) {
      return `${SESSION_COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAgeSeconds}`;
    },
    ttlSeconds: Math.floor(ttl / 1000),
  };
}

function readCookie(header, name) {
  if (!header) return null;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0 && part.slice(0, idx).trim() === name) return part.slice(idx + 1).trim();
  }
  return null;
}

module.exports = { hashPassword, verifyPassword, passwordProblem, createSessions, readCookie, SESSION_COOKIE };
