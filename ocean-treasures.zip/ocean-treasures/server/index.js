const config = require('./config');
const database = require('./db');
const app = require('./app');

async function startServer(options = {}) {
  const cfg = config.load(options);
  const db = database.open(cfg);
  const running = await app.start(cfg, db);
  return {
    url: running.url,
    port: running.port,
    dataDir: cfg.dataDir,
    async stop() {
      await running.close();
      db.close();
    },
  };
}

module.exports = { startServer };
