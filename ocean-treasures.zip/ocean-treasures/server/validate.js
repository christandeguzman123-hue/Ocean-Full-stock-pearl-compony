const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_RE = /^[0-9+\-()\s]{7,25}$/;
const CONTROL_RE = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

function text(value, { min = 0, max, multiline = false, label }) {
  if (value === undefined || value === null) value = '';
  if (typeof value !== 'string') throw fail(`${label} is invalid.`);
  let v = value.replace(CONTROL_RE, '').trim();
  if (!multiline) v = v.replace(/\s+/g, ' ');
  if (v.length < min) throw fail(min === 1 ? `${label} is required.` : `${label} must be at least ${min} characters.`);
  if (v.length > max) throw fail(`${label} must be at most ${max} characters.`);
  return v;
}

function fail(message) {
  const err = new Error(message);
  err.status = 400;
  err.expose = true;
  return err;
}

function email(value) {
  const v = text(value, { min: 1, max: 254, label: 'Email address' });
  if (!EMAIL_RE.test(v)) throw fail('Please enter a valid email address.');
  return v;
}

function phone(value, required) {
  const v = text(value, { min: required ? 1 : 0, max: 25, label: 'Contact number' });
  if (v && (!PHONE_RE.test(v) || v.replace(/\D/g, '').length < 7)) throw fail('Please enter a valid contact number.');
  return v;
}

function requireConsent(value) {
  if (value !== true) throw fail('You must agree to the Data Privacy Notice before submitting.');
}

function inquiry(body) {
  requireConsent(body.consent);
  return {
    name: text(body.name, { min: 2, max: 100, label: 'Name' }),
    email: email(body.email),
    phone: phone(body.phone, false),
    subject: text(body.subject, { max: 120, label: 'Subject' }),
    message: text(body.message, { min: 10, max: 2000, multiline: true, label: 'Message' }),
    marketingOptIn: body.marketing === true,
  };
}

function order(body) {
  requireConsent(body.consent);
  if (!Array.isArray(body.items) || body.items.length === 0) throw fail('Your cart is empty.');
  if (body.items.length > 30) throw fail('Too many different items in one order.');
  const merged = new Map();
  for (const item of body.items) {
    const productId = Number(item && item.id);
    const quantity = Number(item && item.quantity);
    if (!Number.isInteger(productId) || productId < 1) throw fail('Invalid product in cart.');
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 20) throw fail('Quantity must be between 1 and 20.');
    merged.set(productId, Math.min(20, (merged.get(productId) || 0) + quantity));
  }
  return {
    customer: {
      name: text(body.name, { min: 2, max: 100, label: 'Full name' }),
      email: email(body.email),
      phone: phone(body.phone, true),
      address: text(body.address, { min: 10, max: 300, label: 'Delivery address' }),
      notes: text(body.notes, { max: 500, multiline: true, label: 'Notes' }),
      marketingOptIn: body.marketing === true,
    },
    items: [...merged].map(([productId, quantity]) => ({ productId, quantity })),
  };
}

function credentials(body) {
  return {
    username: text(body.username, { min: 3, max: 40, label: 'Username' }),
    password: typeof body.password === 'string' ? body.password : '',
  };
}

module.exports = { inquiry, order, credentials, fail };
